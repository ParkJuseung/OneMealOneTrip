package com.test.foodtrip.global.oauth;

public class Test {
}
