package com.test.foodtrip.global.auth;

public class Test {
}
