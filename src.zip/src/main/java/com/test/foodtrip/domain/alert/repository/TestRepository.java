package com.test.foodtrip.domain.alert.repository;

public class TestRepository {
}
