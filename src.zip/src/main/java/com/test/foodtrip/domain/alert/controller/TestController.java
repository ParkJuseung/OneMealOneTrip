package com.test.foodtrip.domain.alert.controller;

public class TestController {
}
