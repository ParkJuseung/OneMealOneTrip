package com.test.foodtrip.domain.alert.entity;

public class TestEntity {
}
