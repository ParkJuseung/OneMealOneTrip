package com.test.foodtrip.domain.alert.dto;

public class TestDTO {
}
