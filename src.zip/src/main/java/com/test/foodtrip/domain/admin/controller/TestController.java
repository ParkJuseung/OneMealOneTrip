package com.test.foodtrip.domain.admin.controller;

public class TestController {
}
