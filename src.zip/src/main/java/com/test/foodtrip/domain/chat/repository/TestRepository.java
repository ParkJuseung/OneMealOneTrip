package com.test.foodtrip.domain.chat.repository;

public class TestRepository {
}
