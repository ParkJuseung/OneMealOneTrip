package com.test.foodtrip.domain.post.entity;

public class TestEntity {
}
