package com.test.foodtrip.domain.post.service;

public class TestService {
}
