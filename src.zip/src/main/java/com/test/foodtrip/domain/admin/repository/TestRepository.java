package com.test.foodtrip.domain.admin.repository;

public class TestRepository {
}
