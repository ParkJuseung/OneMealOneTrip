package com.test.foodtrip.domain.post.repository;

public class TestRepository {
}
