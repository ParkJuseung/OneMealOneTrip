package com.test.foodtrip.domain.chat.entity;

public class TestEntity {
}
