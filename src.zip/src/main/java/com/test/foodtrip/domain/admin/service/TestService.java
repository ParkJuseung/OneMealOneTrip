package com.test.foodtrip.domain.admin.service;

public class TestService {
}
