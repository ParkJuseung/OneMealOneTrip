
package com.test.foodtrip.domain.user.service;

public class UserService {
}
