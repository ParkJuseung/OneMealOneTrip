package com.test.foodtrip.domain.chat.dto;

public class TestDTO {
}
