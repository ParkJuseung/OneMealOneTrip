package com.test.foodtrip.domain.travel.service;

public class TestService {
}
