package com.test.foodtrip.domain.user.controller;

public class TestController {
}
