package com.test.foodtrip.domain.travel.entity;

public class TestEntity {
}
