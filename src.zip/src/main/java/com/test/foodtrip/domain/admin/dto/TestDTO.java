package com.test.foodtrip.domain.admin.dto;

public class TestDTO {
}
