package com.test.foodtrip.domain.travel.controller;

public class TestController {
}
