package com.test.foodtrip.domain.chat.service;

public class TestService {
}
