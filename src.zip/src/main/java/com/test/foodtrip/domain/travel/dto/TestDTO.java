package com.test.foodtrip.domain.travel.dto;

public class TestDTO {
}
