package com.test.foodtrip.domain.user.controller;

public class UserController {
}
