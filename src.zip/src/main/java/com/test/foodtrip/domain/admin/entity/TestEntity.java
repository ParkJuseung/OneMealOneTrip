package com.test.foodtrip.domain.admin.entity;

public class TestEntity {
}
