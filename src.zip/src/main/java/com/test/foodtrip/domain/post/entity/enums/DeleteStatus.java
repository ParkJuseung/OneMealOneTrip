package com.test.foodtrip.domain.post.entity.enums;

public enum DeleteStatus {
    Y, N
}