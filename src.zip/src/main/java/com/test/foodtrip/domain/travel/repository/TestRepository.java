package com.test.foodtrip.domain.travel.repository;

public class TestRepository {
}
