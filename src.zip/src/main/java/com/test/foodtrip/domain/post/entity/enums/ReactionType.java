package com.test.foodtrip.domain.post.entity.enums;

public enum ReactionType {
    LIKE, DISLIKE
}