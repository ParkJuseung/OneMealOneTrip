package com.test.foodtrip.domain.alert.service;

public class TestService {
}
