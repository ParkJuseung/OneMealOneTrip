package com.test.foodtrip.common.aop;

public class test {
}
