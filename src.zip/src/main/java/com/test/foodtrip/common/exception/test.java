package com.test.foodtrip.common.exception;

public class test {
}
