package com.test.foodtrip.config;

public class JpaConfig {
}
