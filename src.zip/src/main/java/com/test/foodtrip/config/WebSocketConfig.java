package com.test.foodtrip.config;

public class WebSocketConfig {
}
