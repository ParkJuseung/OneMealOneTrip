package com.test.foodtrip.config;

public class OAuth2Config {
}
